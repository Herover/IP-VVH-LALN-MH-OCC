import java.util.HashMap;
import java.util.Map;

/**
 * Kursus med tilhørende tidstabel.
 */
public class Course extends Scheme {

    public Course(String name) {
        super(name);
    }

}
